const THEME = {
  COLORS: {
    PRIMARY_DARK: "#388E3C",
    PRIMARY_LIGHT: "#C8E6C9",
    SECONDARY_TEXT: "#757575",
    PRIMARY: "#4CAF50",
    WHITE: "#FFFFFF"
  }
}

export default THEME