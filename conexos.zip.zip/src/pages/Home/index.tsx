import Header from "components/header"


function Home() {


  return (
    <>
      <Header />
      <a href="/teste">Pagina teste</a>
      <div>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Est, quo ab necessitatibus esse quis eum culpa laboriosam a consequuntur deserunt maiores et expedita incidunt beatae ea? Iste quos doloremque dolore?</div>
    </>
  )
}

export default Home
